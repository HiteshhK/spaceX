export const environment = {
  production: true,
  baseUrl:'https://api.spacexdata.com/v3/launches?limit=100'
};
